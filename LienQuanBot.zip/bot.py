import os
import requests
import asyncio
import time
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from telegram.constants import ParseMode

TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
ADMIN_TELEGRAM_ID = int(os.environ.get("ADMIN_TELEGRAM_ID", "0"))

API_URL = "https://keyherlyswar.x10.mx/Apidocs/reg/reglq.php"
MAX_ACCOUNTS = 20
COOLDOWN_SECONDS = 5 * 60

user_last_scan = {}


def is_admin(user_id: int) -> bool:
    return user_id == ADMIN_TELEGRAM_ID


def get_remaining_cooldown(user_id: int) -> int:
    if user_id not in user_last_scan:
        return 0
    elapsed = time.time() - user_last_scan[user_id]
    remaining = COOLDOWN_SECONDS - elapsed
    return int(remaining) if remaining > 0 else 0


def get_account():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }
    try:
        response = requests.get(API_URL, headers=headers, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get("status") is True and "result" in data:
                return data["result"][0]
            else:
                return {"error": data.get("message", "Lỗi không xác định từ API")}
        else:
            return {"error": f"Lỗi HTTP {response.status_code}"}
    except Exception as e:
        return {"error": str(e)}


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = (
        "👾 *Tool Scan Acc Liên Quân* 👾\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "📌 *Các lệnh hỗ trợ:*\n"
        "🔹 `/acc` — Lấy 1 tài khoản Liên Quân\n"
        "🔹 `/help` — Hướng dẫn sử dụng\n\n"
        "📝 Gõ `/acc` để lấy tài khoản\n\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "📢 *Kênh:* [ipaioshackk](https://t.me/ipaioshackk)\n"
        "💬 *Chat:* [ipahackgameios](https://t.me/ipahackgameios)"
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = (
        "📖 *Hướng dẫn sử dụng:*\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Dùng lệnh `/acc` để lấy *1 tài khoản* Liên Quân.\n\n"
        f"⏱ Mỗi lần lấy xong phải đợi *5 phút* mới được lấy tiếp.\n\n"
        "📝 *Ví dụ:*\n"
        "`/acc` — Lấy 1 tài khoản\n\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "📢 *Kênh:* [ipaioshackk](https://t.me/ipaioshackk)\n"
        "💬 *Chat:* [ipahackgameios](https://t.me/ipahackgameios)"
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)


async def acc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_admin(user_id):
        remaining = get_remaining_cooldown(user_id)
        if remaining > 0:
            minutes = remaining // 60
            seconds = remaining % 60
            await update.message.reply_text(
                f"⏳ Bạn cần đợi thêm *{minutes} phút {seconds} giây* trước khi lấy tiếp\\.",
                parse_mode=ParseMode.MARKDOWN_V2
            )
            return

        count = 1
    else:
        if context.args:
            try:
                count = int(context.args[0])
            except ValueError:
                await update.message.reply_text("❌ Số lượng không hợp lệ. Vui lòng nhập một số nguyên.")
                return
            if count <= 0:
                await update.message.reply_text("❌ Số lượng phải lớn hơn 0.")
                return
            if count > MAX_ACCOUNTS:
                await update.message.reply_text(f"⚠️ Tối đa *{MAX_ACCOUNTS} tài khoản* mỗi lần.", parse_mode=ParseMode.MARKDOWN)
                return
        else:
            count = 1

    loading_msg = await update.message.reply_text(
        f"⏳ Đang lấy *{count}* tài khoản Liên Quân, vui lòng chờ...",
        parse_mode=ParseMode.MARKDOWN
    )

    results = []
    failed = 0

    for _ in range(count):
        result = get_account()
        if "account" in result and "password" in result:
            results.append(f"👤 `{result['account']}:{result['password']}`")
        else:
            failed += 1
        await asyncio.sleep(0.5)

    await loading_msg.delete()

    if not results:
        await update.message.reply_text("❌ Không lấy được tài khoản nào. API có thể đang lỗi.")
        return

    if not is_admin(user_id):
        user_last_scan[user_id] = time.time()

    header = (
        f"✅ *Kết quả Scan Acc Liên Quân*\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"📊 Thành công: *{len(results)}* | Thất bại: *{failed}*\n"
        f"━━━━━━━━━━━━━━━━━━\n"
    )

    accounts_text = "\n".join(results)
    full_msg = header + accounts_text + "\n━━━━━━━━━━━━━━━━━━"

    if len(full_msg) > 4096:
        await update.message.reply_text(header, parse_mode=ParseMode.MARKDOWN)
        chunks = [results[i:i+20] for i in range(0, len(results), 20)]
        for chunk in chunks:
            await update.message.reply_text("\n".join(chunk), parse_mode=ParseMode.MARKDOWN)
    else:
        await update.message.reply_text(full_msg, parse_mode=ParseMode.MARKDOWN)


def main():
    if not TELEGRAM_BOT_TOKEN:
        print("❌ Lỗi: Chưa cấu hình TELEGRAM_BOT_TOKEN")
        return

    print("🤖 Bot Scan Acc Liên Quân đang khởi động...")
    print(f"👑 Admin ID: {ADMIN_TELEGRAM_ID}")

    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("acc", acc))

    print("✅ Bot đã sẵn sàng!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
